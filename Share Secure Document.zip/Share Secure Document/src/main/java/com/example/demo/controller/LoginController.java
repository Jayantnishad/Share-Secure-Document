package com.example.demo.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.DocumentDetail;

import com.example.demo.service.EncryptionService;

import com.example.demo.service.LoginService;
import com.example.demo.service.RegistrationService;

import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {

	String username;
	@Autowired
	LoginService loginService;
	@Autowired
	RegistrationService regitrationService;
	@Autowired
	EncryptionService encryptionService;

	@RequestMapping("/")
	public String home() {
		return "start.html";
	}

	@RequestMapping("/login")
	public String loginPage() {
	
		return "loginPage.jsp";
	}

	@RequestMapping("/redir")

	public String redirection(HttpSession session) {
		if (username == null)
			return "redirect:/";
	
		List<DocumentDetail> ls = loginService.getIndividualReceiveFiles(username);
		session.setAttribute("revlist", ls);
		List<DocumentDetail> ls1 = loginService.getIndividualSendFiles(username);
		session.setAttribute("sendlist", ls1);
		session.setAttribute("user", username);

		return "homePage.jsp";
	}

	@RequestMapping("/verifyLogin")
	public String verifyLogin(String v1, String v2, HttpSession session) {

		username = v1;

		if (loginService.checkCredentials(v1, v2)) {
			return "redirect:/redir";
		}
		
		
		session.setAttribute("logmsg", null);
		if (v1 == null)
			return "redirect:/login";
		else if (v1 == "" || v2 == "") {
			session.setAttribute("message", "Fields are null");
			return "loginPage.jsp";
		} else if (loginService.confirmEmployeePresence(v1)) {
			session.setAttribute("message", "Employee not Found.");
			return "loginPage.jsp";
		} else if (!v1.equals(v2)) {
			session.setAttribute("message", "Invalid username or password!");
			return "loginPage.jsp";
		} else {
			

			return "redirect:/login";
		}
	}

	@RequestMapping("/fileUpload")
	public String fileUpload(String receiver, MultipartFile file, HttpSession session) {
		if (receiver == null) {

			session.setAttribute("fileSavedOrInviteeSameAsInvited", "Invited can't be null.");
		} else if(receiver.equals(username)) {
			session.setAttribute("fileSavedOrInviteeSameAsInvited", "Invitee can't be invited.");
		}
		 else if (loginService.confirmEmployeePresence(receiver)) {
			session.setAttribute("fileSavedOrInviteeSameAsInvited", "Employee not Found.");
		} else {
			loginService.uploadFile(receiver, file, username);
			session.setAttribute("fileSavedOrInviteeSameAsInvited", "File Saved Successfully.");
		}

		System.out.println("Inside /fileUpload");

		return "redirect:/redir";
		

	}

	@RequestMapping("/logout")
	public String logout(HttpSession session, org.springframework.ui.Model model) {
		session.invalidate();
		username = null;
		
		return "redirect:/";
	}

	@GetMapping("/download/{fileId}")
	public ResponseEntity<Resource> downloadFile(@PathVariable int fileId) {
		try {
			Resource resource = loginService.getFileAsResource(fileId);
			return ResponseEntity.ok()
					.header("Content-Disposition", "attachment; filename=\"" + resource.getFilename() + "\"")
					.body(resource);
		} catch (FileNotFoundException e) {

			return ResponseEntity.notFound().build();
		}
	}

}
