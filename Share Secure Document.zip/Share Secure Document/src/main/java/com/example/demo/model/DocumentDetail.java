package com.example.demo.model;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity								
@Table(name="documentdetail")
public class DocumentDetail {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;
    
    private String receiver;
    
    private String sender;
    
    @Column(name = "file_name", columnDefinition = "LONGBLOB")
	private byte[] fileName;

	public DocumentDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DocumentDetail(String receiver,MultipartFile fileName, String sender) {
		super();
		this.receiver = receiver;
		this.sender = sender;
		
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public byte[] getFileName() {
		return fileName;
	}

	public void setFileName(byte[] fileName) {
		this.fileName = fileName;
	}
    
    
    

}
