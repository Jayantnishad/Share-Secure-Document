package com.example.demo.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.DocumentDetail;
import com.example.demo.model.EmployeeRegistration;

import com.example.demo.repository.LoginRepository;
import com.example.demo.repository.RegistrationRepository;

@Service
public class LoginService {
	
	@Autowired
	LoginRepository loginRepository;
	@Autowired
	RegistrationRepository registrationRepository;
	@Autowired
	EncryptionService encryptionService;
	
	public List<DocumentDetail> getIndividualSendFiles(String username) {
		List<DocumentDetail> list = loginRepository.sendFile(username);
		return list;
		
	}
	
	public List<DocumentDetail> getIndividualReceiveFiles(String username) {
		List<DocumentDetail> list = loginRepository.receiveFile(username);
		return list;
		
	}
	

	
	public DocumentDetail uploadFile(String receiver,MultipartFile file,String sender) {
        try {
        	DocumentDetail document = new DocumentDetail(receiver,file,sender);
            document.setTitle(file.getOriginalFilename());
            byte[] originalData = file.getBytes();
            byte[] encryptedData = encryptionService.encrypt(originalData);
            document.setFileName(encryptedData);
            return loginRepository.save(document);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
	
	public boolean checkCredentials(String webAppUserName, String webAppPassword) {
	    EmployeeRegistration employee = registrationRepository.findByWebAppUserNameAndWebAppPassword(webAppUserName, webAppPassword);
	    return employee != null;
	}
	
	public Resource getFileAsResource(int fileId) throws FileNotFoundException {
        // Retrieve file data from database using repository
        Optional<DocumentDetail> fileData = loginRepository.findById(fileId);

        if (fileData.isPresent()) {
        	DocumentDetail file = fileData.get();
        	
        	byte[] dfile = encryptionService.decrypt(file.getFileName());
            // Convert file data to a Resource
            return new ByteArrayResource(dfile);
        } else {
            // Handle case where file is not found in database
            throw new FileNotFoundException("File not found with id " + fileId);
        }
    }
	
	public boolean confirmEmployeePresence(String invited) {

		Optional<EmployeeRegistration> empList = loginRepository.findEmployeePresence(invited);
		
		if(empList.isEmpty())
			return true;
		return false;
	}
	

}
