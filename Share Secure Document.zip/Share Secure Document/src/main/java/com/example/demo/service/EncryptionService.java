package com.example.demo.service;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Service;




@Service
public class EncryptionService {
	
	
	
	 private static final String SECRET_KEY = "A1B2C3D4E5F6G7H8";

	    public byte[] encrypt(byte[] data) {
	        try {
	            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes(), "AES");
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	            return cipher.doFinal(data);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }

	    public byte[] decrypt(byte[] encryptedData) {
	        try {
	            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes(), "AES");
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	            cipher.init(Cipher.DECRYPT_MODE, secretKey);
	            return cipher.doFinal(encryptedData);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }


    



}
