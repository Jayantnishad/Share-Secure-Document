package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.EmployeeRegistration;
import com.example.demo.service.RegistrationService;

import jakarta.servlet.http.HttpSession;

@Controller
public class RegistrationController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@RequestMapping("/register")
	public String registrationPage()
	{
		return "register.jsp";
	}

	@RequestMapping("/registration")
	public String savingDetails(EmployeeRegistration employeeRegistrationObj, HttpSession session)
	{
		if(employeeRegistrationObj.getEmpName() == ""  || employeeRegistrationObj.getWebAppPassword()==""|| employeeRegistrationObj.getWebAppUserName()== "")
		{
			
			session.setAttribute("message","please enter every value above.");
			return "redirect:/register";
		}
		else
		{
			
			registrationService.createEmployee(employeeRegistrationObj);
			return "login";
		}
	}
}
