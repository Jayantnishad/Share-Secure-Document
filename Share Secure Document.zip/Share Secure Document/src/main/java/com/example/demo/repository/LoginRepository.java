package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.DocumentDetail;
import com.example.demo.model.EmployeeRegistration;

@Repository
public interface LoginRepository extends JpaRepository<DocumentDetail,Integer> {

	
	
	
	@Query("from DocumentDetail where receiver=?1")
	List<DocumentDetail> receiveFile(String username);
	
	@Query("from DocumentDetail where sender=?1")
	List<DocumentDetail> sendFile(String username);
	
	
	@Query("from EmployeeRegistration where webAppUserName=?1")
	Optional<EmployeeRegistration> findEmployeePresence(String user);
		
		
	@Query("from EmployeeRegistration where webAppUserName=?1")
	Optional<EmployeeRegistration> getTheEmp(String username);
}
