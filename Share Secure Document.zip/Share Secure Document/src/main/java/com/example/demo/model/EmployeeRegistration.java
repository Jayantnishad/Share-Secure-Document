package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employeeregistration")
public class EmployeeRegistration {
	
	String empName;      //Employee Name
	
	@Id
	String webAppUserName;		// User name to register to the webApp.PRIMARY KEY.
	String webAppPassword;		// Password to register to the webApp
	public EmployeeRegistration() {
		super();
		
	}
	public EmployeeRegistration(String empName, String webAppUserName, String webAppPassword) {
		super();
		this.empName = empName;
		this.webAppUserName = webAppUserName;
		this.webAppPassword = webAppPassword;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getWebAppUserName() {
		return webAppUserName;
	}
	public void setWebAppUserName(String webAppUserName) {
		this.webAppUserName = webAppUserName;
	}
	public String getWebAppPassword() {
		return webAppPassword;
	}
	public void setWebAppPassword(String webAppPassword) {
		this.webAppPassword = webAppPassword;
	}

	
}
