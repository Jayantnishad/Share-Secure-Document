package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.web.bind.annotation.RequestBody;


import com.example.demo.model.EmployeeRegistration;

import com.example.demo.repository.RegistrationRepository;

@Service
public class RegistrationService
{
	@Autowired
	private RegistrationRepository registrationRepository;
	
	public void createEmployee(@RequestBody EmployeeRegistration e)
	{
		registrationRepository.save(e);
	}
	
	

}